<?php

namespace App\Filament\Resources\InternationalFlightResource\Pages;

use App\Filament\Resources\InternationalFlightResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateInternationalFlight extends CreateRecord
{
    protected static string $resource = InternationalFlightResource::class;
}
