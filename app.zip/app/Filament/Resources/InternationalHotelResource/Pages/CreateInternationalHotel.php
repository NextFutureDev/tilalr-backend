<?php

namespace App\Filament\Resources\InternationalHotelResource\Pages;

use App\Filament\Resources\InternationalHotelResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateInternationalHotel extends CreateRecord
{
    protected static string $resource = InternationalHotelResource::class;
}
