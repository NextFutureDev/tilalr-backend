<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Payment;
use App\Models\Booking;
use App\Models\AdminNotifiable;
use App\Notifications\NewBookingPayment;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class PaymentController extends Controller
{
    /**
     * Get all payments for authenticated user
     */
    public function index(Request $request)
    {
        $payments = Payment::with('booking')
            ->whereHas('booking', function($query) use ($request) {
                $query->where('user_id', $request->user()->id);
            })
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json(['payments' => $payments]);
    }

    /**
     * Initiate payment (create payment session and return Moyasar config)
     */
    public function initiate(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'booking_id' => 'required|exists:bookings,id',
            'amount' => 'required|numeric|min:0',
            'method' => 'required|string|in:creditcard,stcpay,mada',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $booking = Booking::find($request->booking_id);

        // Verify booking belongs to user
        if ($booking->user_id !== $request->user()->id) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        // Check if booking already paid
        if ($booking->payment_status === 'paid') {
            return response()->json(['message' => 'Booking already paid'], 422);
        }

        // Create payment record
        $payment = Payment::create([
            'booking_id' => $booking->id,
            'method' => $request->method,
            'status' => 'pending',
            'transaction_id' => null,
            'meta' => [
                'amount' => $request->amount,
                'currency' => 'SAR',
                'gateway' => 'moyasar',
                'initiated_at' => now()->toISOString(),
            ]
        ]);

        Log::info('Payment initiation started', [
            'booking_id' => $booking->id,
            'payment_id' => $payment->id,
            'gateway' => 'moyasar',
            'amount' => $request->amount,
        ]);

        $result = $this->initiateMoyasarPayment($payment, $booking, $request->amount);

        Log::info('Moyasar payment result', [
            'success' => $result['success'] ?? false,
            'error' => $result['error'] ?? null,
        ]);

        if ($result['success']) {
            return response()->json([
                'payment' => $payment->fresh(),
                'moyasar_config' => $result['moyasar_config'],
                'message' => 'Payment initiated successfully'
            ]);
        } else {
            Log::error('Payment initiation failed', [
                'error' => $result['error'] ?? 'Unknown error',
                'booking_id' => $booking->id,
            ]);
            return response()->json([
                'message' => 'Failed to initiate payment',
                'error' => $result['error'] ?? 'Unknown error'
            ], 500);
        }
    }

    /**
     * Initiate Moyasar payment
     * Returns config for embedded Moyasar form (recommended approach)
     */
    private function initiateMoyasarPayment($payment, $booking, $amount)
    {
        $publishableKey = config('services.moyasar.api_key');
        
        if (empty($publishableKey)) {
            Log::error('Moyasar API key not configured');
            return [
                'success' => false,
                'error' => 'Payment gateway not configured'
            ];
        }
        
        $callbackUrl = config('app.frontend_url', 'https://tilalr.com') . '/payment/callback?payment_id=' . $payment->id;

        try {
            // Update payment with transaction reference
            $payment->update([
                'transaction_id' => 'moyasar_' . $payment->id . '_' . time(),
                'meta' => array_merge($payment->meta ?? [], [
                    'moyasar_config' => [
                        'publishable_key' => $publishableKey,
                        'amount' => intval($amount * 100), // Amount in halalas
                        'currency' => 'SAR',
                        'description' => "Booking #{$booking->id} - Tilal Rimal",
                        'callback_url' => $callbackUrl,
                    ],
                    'initiated_at' => now()->toISOString(),
                ])
            ]);

            // Return config for frontend embedded form
            return [
                'success' => true,
                'payment_url' => null, // No redirect - use embedded form
                'redirect_url' => null,
                'moyasar_config' => [
                    'element' => '#moyasar-form',
                    'publishable_api_key' => $publishableKey,
                    'amount' => intval($amount * 100), // Amount in halalas
                    'currency' => 'SAR',
                    'description' => "Booking #{$booking->id} - Tilal Rimal",
                    'callback_url' => $callbackUrl,
                    'methods' => ['creditcard', 'stcpay'],
                    'metadata' => [
                        'booking_id' => $booking->id,
                        'payment_id' => $payment->id,
                    ],
                ],
            ];

        } catch (\Exception $e) {
            Log::error('Moyasar payment initiation failed: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Send notification to admin about new booking payment
     */
    private function notifyAdmin($booking, $payment)
    {
        try {
            $admin = AdminNotifiable::first();
            if ($admin) {
                $admin->notify(new NewBookingPayment($booking, $payment));
                Log::info('Admin notification sent for booking #' . $booking->id);
            }
        } catch (\Exception $e) {
            Log::error('Failed to send admin notification: ' . $e->getMessage());
        }
    }

    /**
     * Moyasar webhook handler
     */
    public function moyasarWebhook(Request $request)
    {
        Log::info('Moyasar webhook received', $request->all());

        $paymentId = $request->input('id');
        $status = $request->input('status');

        $payment = Payment::where('transaction_id', $paymentId)->first();

        if (!$payment) {
            Log::error('Payment not found for Moyasar webhook', ['payment_id' => $paymentId]);
            return response()->json(['message' => 'Payment not found'], 404);
        }

        $booking = $payment->booking;

        if ($status === 'paid') {
            $payment->update([
                'status' => 'paid',
                'meta' => array_merge($payment->meta ?? [], [
                    'moyasar_webhook' => $request->all(),
                    'paid_at' => now()->toISOString(),
                ])
            ]);

            $booking->update([
                'payment_status' => 'paid',
                'status' => 'confirmed',
            ]);

            // Send admin notification
            $this->notifyAdmin($booking, $payment);

            return response()->json(['message' => 'Payment confirmed']);
        } elseif ($status === 'failed') {
            $payment->update([
                'status' => 'failed',
                'meta' => array_merge($payment->meta ?? [], [
                    'moyasar_webhook' => $request->all(),
                    'failed_at' => now()->toISOString(),
                ])
            ]);

            return response()->json(['message' => 'Payment failed']);
        }

        return response()->json(['message' => 'Webhook received']);
    }

    /**
     * Payment callback (user returns from payment gateway)
     */
    public function callback(Request $request)
    {
        $paymentId = $request->input('payment_id');
        $status = $request->input('status', 'pending');

        $payment = Payment::find($paymentId);

        if (!$payment) {
            return response()->json(['message' => 'Payment not found'], 404);
        }

        return response()->json([
            'payment' => $payment->fresh(),
            'booking' => $payment->booking,
            'status' => $status,
        ]);
    }

    /**
     * Get payment details
     */
    public function show(Request $request, $id)
    {
        $payment = Payment::with('booking')->find($id);

        if (!$payment) {
            return response()->json(['message' => 'Payment not found'], 404);
        }

        // Verify user can access this payment
        if ($request->user() && $payment->booking->user_id !== $request->user()->id) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        return response()->json(['payment' => $payment]);
    }
}
